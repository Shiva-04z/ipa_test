import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HPPoliceController extends GetxController {
  // Add hpPolice-specific properties and methods here
  RxString stationName = ''.obs;
  RxString jurisdiction = ''.obs;
}

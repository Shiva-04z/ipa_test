import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HPAgriBoardController extends GetxController {
  // Add hpAgriBoard-specific properties and methods here
  RxString boardName = ''.obs;
  RxString region = ''.obs;
}

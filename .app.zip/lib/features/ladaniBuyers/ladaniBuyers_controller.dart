import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LadaniBuyersController extends GetxController {
  // Add ladaniBuyers-specific properties and methods here
  RxString companyName = ''.obs;
  RxString businessType = ''.obs;
}

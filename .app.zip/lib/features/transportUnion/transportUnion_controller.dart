import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TransportUnionController extends GetxController {
  // Add transportUnion-specific properties and methods here
  RxString unionName = ''.obs;
  RxString registrationNumber = ''.obs;
}

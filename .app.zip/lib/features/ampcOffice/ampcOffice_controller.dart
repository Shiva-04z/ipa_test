import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AmpcOfficeController extends GetxController {
  // Add ampcOffice-specific properties and methods here
  RxString officeName = ''.obs;
  RxString region = ''.obs;
}

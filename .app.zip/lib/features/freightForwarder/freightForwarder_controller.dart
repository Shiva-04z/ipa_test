import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FreightForwarderController extends GetxController {
  // Add freightForwarder-specific properties and methods here
  RxString companyName = ''.obs;
  RxString licenseNumber = ''.obs;
}

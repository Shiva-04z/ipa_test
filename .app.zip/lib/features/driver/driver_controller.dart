import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DriverController extends GetxController {
  // Add driver-specific properties and methods here
  RxString driverName = ''.obs;
  RxString licenseNumber = ''.obs;
}

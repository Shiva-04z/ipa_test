import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AadhatiController extends GetxController {
  // Add aadhati-specific properties and methods here
  RxString aadhatiName = ''.obs;
  RxString region = ''.obs;
}

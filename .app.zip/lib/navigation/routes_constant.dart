class RoutesConstant{
  static String splash = "/splashPage";
  static String signUp = "/signupPage";
  static String grower = "/growerPage";

  static String packHouse = "/packHousePage";
  static String aadhati = "/aadhatiPage";
  static String ladaniBuyers = "/ladaniBuyersPage";
  static String freightForwarder = "/freightForwarderPage";
  static String driver = "/driverPage";
  static String transportUnion = "/transportUnionPage";
  static String ampcOffice = "/ampcOfficePage";
  static String hpPolice = "/hpPolicePage";
  static String hpAgriBoard = "/hpAgriBoardPage";
}
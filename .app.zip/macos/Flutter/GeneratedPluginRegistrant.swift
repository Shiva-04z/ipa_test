//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import file_picker
import geolocator_apple

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FilePickerPlugin.register(with: registry.registrar(forPlugin: "FilePickerPlugin"))
  GeolocatorPlugin.register(with: registry.registrar(forPlugin: "GeolocatorPlugin"))
}

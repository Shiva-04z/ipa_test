package com.example.apple_grower

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
